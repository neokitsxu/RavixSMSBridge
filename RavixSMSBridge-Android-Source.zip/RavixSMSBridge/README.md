# Ravix SMS Bridge — Android source project

This is an Android Studio source project (Java) for a companion app that listens only for incoming NSDL Payments Bank credit-alert SMS messages matching the sample format supplied by the user. It extracts sender, credited amount, date, UPI reference number and masked account suffix, then posts those structured fields to a configured HTTPS backend.

## Important status

- This package is **source code, not a compiled APK**. The current build environment has Java but no Android SDK/Gradle installation, so an APK could not be built or tested here.
- This is the Android companion component only. A compatible Paymenter v2 gateway and authenticated backend endpoint must be deployed before forwarding can work.
- SMS notification parsing is not bank-grade proof of settlement. Do not automatically mark invoices paid solely from an SMS. Reconcile the UTR/amount against a trusted bank statement or official bank/provider verification source; otherwise leave it pending for admin review.

## Build

Open this folder in Android Studio, install Android SDK 35, then Build > Build APK(s). The resulting debug APK is normally under `app/build/outputs/apk/debug/`.

## Setup

1. Install the APK on the Android device that receives NSDL credit alerts.
2. Enter your backend HTTPS base URL and a device pairing token issued by the backend.
3. Grant the SMS permission when prompted.
4. Disable battery optimization for the app and keep the phone powered and connected. Android/OEM power management can still delay delivery.
5. Send a small test payment and verify the parsed event in backend logs before enabling any automated invoice workflow.

## Backend contract

`POST /api/sms-bridge/v1/credits`

Headers:
- `Authorization: Bearer <device-pairing-token>`
- `Content-Type: application/json`

JSON body example:

```json
{
  "sender": "VM-NSDLPB-S",
  "amount": "20.00",
  "date": "12-Nov-26",
  "utr": "519493424404",
  "account_suffix": "6032",
  "source": "ravix_sms_bridge"
}
```

Backend must authenticate the token, rate-limit requests, store UTRs uniquely, reject duplicates, validate amount/date, and never trust a client-supplied event as sufficient proof of payment. Only accept HTTPS. The app deliberately does not upload the complete SMS body or unrelated messages.

## Privacy and distribution

The app requests `RECEIVE_SMS` and does not request `READ_SMS` or send messages. Sideloading may be required; Google Play restricts SMS permissions and requires policy eligibility. Do not publish it on Play without reviewing current Play policy and obtaining appropriate user consent.
