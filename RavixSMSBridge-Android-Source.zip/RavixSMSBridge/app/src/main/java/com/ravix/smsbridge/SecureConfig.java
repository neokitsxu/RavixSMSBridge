package com.ravix.smsbridge;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

public final class SecureConfig {
    private static SharedPreferences prefs(Context c) throws Exception {
        MasterKey key = new MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build();
        return EncryptedSharedPreferences.create(c, "ravix_secure_config", key,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);
    }
    public static void save(Context c, String url, String token) throws Exception {
        prefs(c).edit().putString("url", url.trim()).putString("token", token.trim()).apply();
    }
    public static String url(Context c) { try { return prefs(c).getString("url", ""); } catch (Exception e) { return ""; } }
    public static String token(Context c) { try { return prefs(c).getString("token", ""); } catch (Exception e) { return ""; } }
    private SecureConfig() {}
}
