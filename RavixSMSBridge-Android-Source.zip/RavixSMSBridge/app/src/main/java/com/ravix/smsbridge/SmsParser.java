package com.ravix.smsbridge;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class SmsParser {
    private static final Pattern CREDIT = Pattern.compile("(?is)A/c\\s+no\\s+XX\\d+\\s+is\\s+credited\\s+for\\s+Rs\\.?\\s*([0-9,]+(?:\\.[0-9]{1,2})?).*?on\\s+(\\d{1,2}-[A-Za-z]{3}-\\d{2,4}).*?UPI\\s+Ref\\s+No\\s+([0-9]{8,20})");
    public static Event parse(String sender, String body) {
        if (sender == null || body == null) return null;
        String s = sender.toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]", "");
        if (!(s.contains("NSDLPB") || s.contains("NSDL"))) return null;
        Matcher m = CREDIT.matcher(body);
        if (!m.find()) return null;
        String amount = m.group(1).replace(",", "");
        String date = m.group(2);
        String utr = m.group(3);
        String suffix = "";
        Matcher a = Pattern.compile("(?i)A/c\\s+no\\s+XX(\\d+)").matcher(body);
        if (a.find()) suffix = a.group(1);
        return new Event(sender, amount, date, utr, suffix);
    }
    public static final class Event {
        public final String sender, amount, date, utr, accountSuffix;
        Event(String s, String a, String d, String u, String x) { sender=s; amount=a; date=d; utr=u; accountSuffix=x; }
    }
    private SmsParser() {}
}
