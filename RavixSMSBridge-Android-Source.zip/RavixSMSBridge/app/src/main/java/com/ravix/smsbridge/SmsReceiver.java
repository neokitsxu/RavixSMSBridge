package com.ravix.smsbridge;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import androidx.work.Data;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

public class SmsReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (!Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) return;
        for (android.telephony.SmsMessage sms : Telephony.Sms.Intents.getMessagesFromIntent(intent)) {
            if (sms == null) continue;
            SmsParser.Event event = SmsParser.parse(sms.getOriginatingAddress(), sms.getMessageBody());
            if (event == null) continue;
            Data data = new Data.Builder()
                    .putString("sender", event.sender)
                    .putString("amount", event.amount)
                    .putString("date", event.date)
                    .putString("utr", event.utr)
                    .putString("account_suffix", event.accountSuffix)
                    .build();
            OneTimeWorkRequest work = new OneTimeWorkRequest.Builder(ForwardWorker.class)
                    .setInputData(data).build();
            WorkManager.getInstance(context).enqueue(work);
        }
    }
}
