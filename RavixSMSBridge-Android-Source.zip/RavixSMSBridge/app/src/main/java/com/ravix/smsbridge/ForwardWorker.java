package com.ravix.smsbridge;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import org.json.JSONObject;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class ForwardWorker extends Worker {
    public ForwardWorker(@NonNull Context c, @NonNull WorkerParameters p) { super(c,p); }
    @NonNull @Override public Result doWork() {
        String base = SecureConfig.url(getApplicationContext());
        String token = SecureConfig.token(getApplicationContext());
        if (base.isEmpty() || token.isEmpty()) return Result.failure();
        HttpURLConnection conn = null;
        try {
            JSONObject json = new JSONObject();
            json.put("sender", getInputData().getString("sender"));
            json.put("amount", getInputData().getString("amount"));
            json.put("date", getInputData().getString("date"));
            json.put("utr", getInputData().getString("utr"));
            json.put("account_suffix", getInputData().getString("account_suffix"));
            json.put("source", "ravix_sms_bridge");
            conn = (HttpURLConnection) new URL(base.replaceAll("/$", "") + "/api/sms-bridge/v1/credits").openConnection();
            conn.setRequestMethod("POST"); conn.setConnectTimeout(12000); conn.setReadTimeout(12000);
            conn.setDoOutput(true); conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Authorization", "Bearer " + token);
            byte[] payload = json.toString().getBytes(StandardCharsets.UTF_8);
            conn.setFixedLengthStreamingMode(payload.length);
            try (OutputStream os = conn.getOutputStream()) { os.write(payload); }
            int code = conn.getResponseCode();
            if (code >= 200 && code < 300) return Result.success();
            if (code == 401 || code == 403 || code == 400) return Result.failure();
            return Result.retry();
        } catch (Exception e) { return Result.retry(); }
        finally { if (conn != null) conn.disconnect(); }
    }
}
