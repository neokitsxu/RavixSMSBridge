package com.ravix.smsbridge;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {
    private EditText url, token;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(32,40,32,32);
        TextView title = new TextView(this); title.setText("Ravix SMS Bridge"); title.setTextSize(26); title.setGravity(Gravity.CENTER); root.addView(title);
        TextView desc = new TextView(this); desc.setText("Forwards only parsed NSDL credit alerts. It does not read or upload your full inbox."); desc.setPadding(0,20,0,24); root.addView(desc);
        url = new EditText(this); url.setSingleLine(true); url.setHint("Backend URL (https://your-domain)"); url.setInputType(InputType.TYPE_TEXT_VARIATION_URI); url.setText(SecureConfig.url(this)); root.addView(url);
        token = new EditText(this); token.setSingleLine(true); token.setHint("Device pairing token"); token.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD); token.setText(SecureConfig.token(this)); root.addView(token);
        Button save = new Button(this); save.setText("Save & Enable SMS Bridge"); root.addView(save);
        TextView status = new TextView(this); status.setPadding(0,24,0,0); status.setText("Status: SMS permission required"); root.addView(status);
        save.setOnClickListener(v -> {
            String endpoint = url.getText().toString().trim();
            if (!endpoint.startsWith("https://")) { Toast.makeText(this,"Use an HTTPS backend URL",Toast.LENGTH_LONG).show(); return; }
            try { SecureConfig.save(this, endpoint, token.getText().toString()); } catch (Exception e) { Toast.makeText(this,"Could not securely save settings",Toast.LENGTH_LONG).show(); return; }
            requestSmsPermission();
            status.setText("Settings saved. Grant SMS permission and keep battery access unrestricted for reliable delivery.");
        });
        setContentView(root);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED) status.setText("Status: SMS permission granted");
    }
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECEIVE_SMS}, 1001);
    }
}
